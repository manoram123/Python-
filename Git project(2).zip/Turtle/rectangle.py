import turtle
window= turtle.Screen()
p= turtle.Turtle()
def function(l,b,x,y):
    if l>150:
        pass
    else:
        p.up()
        p.goto(x,y)
        p.down()
        p.forward(l)
        p.left(90)
        p.forward(b)
        p.left(90)
        p.forward(l)
        p.left(90)
        p.forward(b)
        p.left(90)
        function(l+20,b+20,x-10,y-10)
function(70,50,0,0)
turtle.done()
