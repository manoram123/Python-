import turtle
wn=turtle.Screen()
pen=turtle.Turtle()

def c(r,x,y):
    if r<10:
        pass
    else:
        pen.up()
        pen.goto(x,y)
        pen.down()
        pen.circle(r)
        c(r-20,x,y+20)
c(100,0,0)
turtle.done()
