a={2,3,4,5}
b={4,5,6,7,8}
a.difference_update(b)
print(a)