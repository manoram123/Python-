def add():
    a = int(input("enter a:"))
    b = int(input("enter b:"))
    c=a+b
    print(c)
def sub():
    a = int(input("enter a:"))
    b = int(input("enter b:"))
    c=a-b
    print(c)
def multi():
    a = int(input("enter a:"))
    b = int(input("enter b:"))
    c=a*b
    print(c)
def div(a,b):
    a = int(input("enter a:"))
    b = int(input("enter b:"))
    c=a/b
    print(c)
