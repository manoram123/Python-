x= int(input("Enter a number:"))
y= int(input("Enter Second Number:"))
z= int(input("Enter third Number:"))
print("The Sum of these numbers is:",  x+y+z)
