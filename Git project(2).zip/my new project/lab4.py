x= int(input("Enter an Integer:"))
print(x,"minutes have passed from midnight.")
print("The time is:", x//60,":",x%60 )
