n= int(input("The number of Students:"))
k= int(input("The number of Apples:"))
x=k//n
print("Each students get:",x, "Apples")
print("Remaining Apples:",k%n)
