s= int(input("Enter Seconds:"))
d= s//(24*3600)
print("Day:",d)
h= (s%(24*3600))//(3600)
print("Hours:",h)
m= (s%(24*3600))//(60)
print("Minutes:",m)
sec= (s%(24*3600))
print("Seconds:",sec)










