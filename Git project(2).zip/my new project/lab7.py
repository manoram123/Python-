d= 4
s= 25
t= d/(s/60)
print("Time Taken By bus:",t+20)
t1= 1/(7/60)
t2= 2/(15/60)
tw= 2*t1+t2
print("Time Taken to walk:",tw)
