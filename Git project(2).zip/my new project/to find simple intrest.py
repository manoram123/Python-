x= int(input("Enter P:"))
y= int(input("Enter Rate:"))
z= int(input("Enter Time:"))
print("Simple intrest:",(x*y*z)/100)
