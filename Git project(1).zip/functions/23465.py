def add():
    a = int(input("A="))
    b = int(input("B="))
    c = a + b
    print("Sum=", c)
add()
