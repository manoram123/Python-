f= open('marsh.jpg','rb')
i= f.read()
n= open('man.txt','wb')
n.write(i)
n.close()
f.close()
f=open('man.txt','wb')
lst=[12,13,14,15]
temp=bytes(lst)
f.write(temp)
f.close()
f=open('man.txt','rb')
x=f.read()
for i in x:
    print(int(i))
f.close()

