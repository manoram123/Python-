import pickle

def save():
    man={'key':'manoram','name':'Manoram Baudel','age':18}
    ram={'key':'ram','name':'ram baral','age':27}
    db={}
    db['mano']=man
    db['ramo']=ram
    f= open('pickle.txt','ab')
    pickle.dump(db,f)
    f.close()
def load():
    f= open('pickle.txt','rb')
    db=pickle.load(f)
    for keys in db:
        print(keys,':',db[keys])
    f.close()
save()
load()
