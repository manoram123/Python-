x= int(input('set the limit:'))
a=0
while a<x:
    if a%2==0:
        print(a,'EVEN')
    elif x%2!=0:
        print(a,'ODD')
    a=a+1
