x=int(input("enter a number:"))
rev=0
original=x
while x>0:
    a=x%10
    rev=rev*10+a
    x=x//10
if rev==original:
    print("Palindrome")
else:
    print("Non Palindrome")
