x= int(input('enter a number:'))
c=0
a=1
while a<=x:
    if x%2==0:
        c=c+1
    a=a+1
if c>2:
    print('Composite Number')
else:
    print('Prime Number')
