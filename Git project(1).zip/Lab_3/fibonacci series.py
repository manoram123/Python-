a=0
b=1
c=1
c=a+b
print(c)
for i in range(0,19):
    c=a+b
    a=b
    b=c
    print(c)