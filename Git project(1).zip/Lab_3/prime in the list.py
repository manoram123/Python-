x= int(input('number of elements:'))
l=[]
for i in range(1,x+1):
    a=int(input('enter element:'))
    l.append(a)
print(l)
c=0
while a<=len(l):
    if l[a]%2==0:
        c=c+1
    print(c)
    a=a+1
