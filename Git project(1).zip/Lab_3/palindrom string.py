x= input("Enter a string:")
a=1
b=1
c=[]

while a<=len(x):
    v=(x[-a])
    a=a+1
    c.append(v)
print(c)
d=(list(x))
print(d)
if c==d:
    print(x,'is a pallindrome!')
else:
    print(x,'is not a pallindrome!')




