x= int(input('number of elements:'))
l=[]
for i in range(1,x+1):
    a=int(input('enter element:'))
    l.append(a)
print(l)
for a in range(0,len(l)):
    if l[a]%2!=0:
        print(l[a])
