x= "******"
i=1
while i<=len(x):
    p=x[0:-i]
    i=i+1
    print(p)

