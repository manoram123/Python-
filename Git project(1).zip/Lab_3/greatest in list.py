x=int(input('number of elements:'))
l=[]
i=1
while i<=x:
    a=int(input('enter element:'))
    i=i+1
    l.append(a)
print(l)
greatest=l[0]
for a in range(1,len(l)):
    if l[a]>l[0]:
        greatest=l[a]
        break
print(greatest)