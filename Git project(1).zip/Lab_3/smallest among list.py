x= int(input('number of elements:'))
l=[]
for i in range(1,x+1):
    a=int(input('enter element:'))
    l.append(a)
print(l)
smallest= l[0]
for a in range(1,len(l)):
    if l[a]<l[0]:
        smallest=l[a]
print(smallest)