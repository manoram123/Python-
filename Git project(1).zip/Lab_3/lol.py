x=7
a=1
c=0
while a<=x:
    if x%a==0:
        c=c+1
    a=a+1
if c==2:
    print("prime")
else:
    print("composite ")
