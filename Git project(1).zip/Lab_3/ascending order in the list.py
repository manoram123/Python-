x= int(input('number of elements:'))
l=[]
for i in range(1,x+1):
    a=int(input('enter element:'))
    l.append(a)
print(l)
a=0
for i in range
    if l[a]%2!=0:
        a=l[a]
        print(a)