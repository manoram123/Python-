import pickle
import os
d={}
l = os.path.getsize('C:\\Users\\LEGION\\PycharmProjects\\Assignment Project\\sms.txt')
def insert():
    global d
    user = input('Enter Username:')
    passw = input('Enter Password:')
    d1 = {user:passw}
    if l>0:
        file = open('sms.txt','rb+')
        d=pickle.load(file)
        d.update(d1)
        file.seek(0)
        pickle.dump(d,file)
        file.close()
    else:
        file= open('sms.txt','wb')
        d.update(d1)
        pickle.dump(d,file)
        file.close()
def view():
    if l>0:
        f=open('sms.txt','rb')
        ld=pickle.load(f)
        for i,j in ld.items():
            print('username '+i)
            print('pass: '+j)
        f.close()
insert()
view()



