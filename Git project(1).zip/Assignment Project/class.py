from tkinter import *
wn=Tk()
def home():
    wn.geometry('340x420')
    Label(text='Home',font=('calabri',20,'bold')).pack()
