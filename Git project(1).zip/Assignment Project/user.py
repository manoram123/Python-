
l={'username':(input('Userame:')),'password':(input('Password:'))}
x= input("Username:")
y= input("Password:")
if l['username']==x and l['password']==y:
    print("Welcome!")
else:
    print('Invalid!')