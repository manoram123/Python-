from tkinter import *
import pickle
screen= Tk()
screen.geometry('200x220')
username=StringVar()
password=StringVar()
def save():
    file=open('save.txt','wb')
    user={username.get():password.get()}
    pickle.dump(user,file)
    next_user={}
    user=next_user
    file.close()
l1=Label(screen,text='Welcome',bg='grey',height=2, width=420,font=(('samanata'),20,'bold')).pack()
l2=Label(screen,text='username*').pack()
e1=Entry(textvariable=username).pack()
l3=Label(screen,text='password*').pack()
e2=Entry(textvariable=password).pack()
b1= Button(text='Register',font='calabri',command=save).pack()
screen.mainloop()
def funcn():
    f= open('save.txt','rb')
    v=pickle.load(f)
    print(str(v))
    f.close()
funcn()