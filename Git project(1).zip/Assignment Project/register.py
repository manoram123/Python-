from tkinter import *
wn= Tk()
def welcome():
    wel=Toplevel(screen1)
    wel.title("welcome")
    wel.geometry('420x640')
    Label(wel,text="Welcome",bg='grey',font=('calabri',20,'bold'),height=3,width=420).pack()

def pas():
    user1=username.get()
    pass1=password.get()
    global v
    f=open('user.txt')
    v= f.read().splitlines()
    if user1 in v:
        if pass1 in v:
            welcome()
        else:
            Label(screen1, text="Invalid Username or Password!", fg='red', font=('calabri', 12, 'bold')).pack()
    else:
        Label(screen1, text="Username Doesn't Exists!", fg='red', font=('calabri', 12, 'bold')).pack()
def login():
    global screen1
    screen1= Toplevel(wn)
    screen1.title('Login')
    screen1.geometry('420x640')
    global username
    global password
    username= StringVar()
    password= StringVar()
    l1=Label(screen1,text='Login',bg='grey',font=('samanata',20,'bold'),height=2,width=420)
    l1.pack(side='top')
    Label(screen1,text="").pack(pady=40)
    l2=Label(screen1,text='Username*',font='samanata').pack(side='top',padx=10,pady=10)
    e1=Entry(screen1, textvariable=username).pack()
    l3=Label(screen1,text='Password*',font='samanata').pack(side='top',padx=10,pady=10)
    e2=Entry(screen1, textvariable=password).pack()
    Button(screen1,text='Login',font=('calabri',14),command=pas).pack(padx=10,pady=10)
def info():
    fname= first_name.get()
    lname= last_name.get()
    global usrname
    usrname=user_name.get()
    passw=pswrd.get()
    conpass=confirm_password.get()
    global file
    file = open('user.txt', 'a')
    if fname == "":
        Label(screen2, text="Please Provide Required Field!", fg='red', font=('calabri', 12, 'bold')).pack()
    elif usrname == "":
        Label(screen2, text="Please Provide Required Field!", fg='red', font=('calabri', 12, 'bold')).pack()
    elif passw==conpass:
        file.write(fname + '\n')
        file.write(lname + '\n')
        file.write(usrname + '\n')
        file.write(passw + '\n')
        file.close()
        Label(screen2, text="Successfully Registered!", fg='green', font=('calabri', 12, 'bold')).pack()
    elif fname=="":
        Label(screen2, text="Please Provide Required Field!", fg='red', font=('calabri', 12, 'bold')).pack()
    elif usrname == "":
        Label(screen2, text="Please Provide Required Field!", fg='red', font=('calabri', 12, 'bold')).pack()
    elif passw !=conpass:
        Label(screen2, text="Registration Failed!", fg='red', font=('calabri', 12, 'bold')).pack()
def register():
    global screen2
    screen2=Toplevel(wn)
    screen2.title('Register')
    screen2.geometry('420x640')
    global first_name
    global last_name
    global user_name
    global pswrd
    global confirm_password
    first_name= StringVar()
    last_name= StringVar()
    user_name= StringVar()
    pswrd= StringVar()
    confirm_password= StringVar()
    Label(screen2,text='Register',bg='grey',font=('samanata',20,'bold'),height=2,width=420).pack()
    Label(screen2,text="").pack(pady=10)
    l1=Label(screen2,text='First Name*',font=('samanata',12)).pack()
    e1=Entry(screen2,textvariable=first_name).pack()
    l1 = Label(screen2, text='Last Name*', font=('samanata',12)).pack()
    e1 = Entry(screen2, textvariable=last_name).pack()
    l1 = Label(screen2, text='username*', font=('samanata',12)).pack()
    e1 = Entry(screen2, textvariable=user_name).pack()
    l1 = Label(screen2, text='password*', font=('samanata',12)).pack()
    e1 = Entry(screen2, textvariable=pswrd).pack()
    l1 = Label(screen2, text='Confirm Password*', font=('samanata',12)).pack()
    e1 = Entry(screen2, textvariable=confirm_password).pack()
    Button(screen2,text='Register',font='calabri',command=info).pack(pady=10)
def home_screen():
    global wn
    wn.geometry('420x420')
    Label(text="Home",bg='grey',font=('samanata',20,'bold'),height=2,width=640,).pack(side='top')
    b1=Button(text='Login',height=2,width=30,font=('samanata'),command=login).pack(padx=50,pady=10)
    b1 = Button(text='Register', height=2, width=30, font='samanata', command=register).pack(padx=50, pady=10)
    wn.mainloop()
home_screen()
