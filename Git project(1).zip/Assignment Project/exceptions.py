from register.py import *
class Error(Exception):
    def __init__(self,msg):
        self.msg=msg
def withdraw(amount):
    balance=5000
    if amount>balance:
        raise InvalidFund("Insufficient Amount")
    else:
        b= balance-amount


