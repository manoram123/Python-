import pickle
d={}
my_file=open('manoram.txt','ab')
pickle.dump(d,my_file)
my_file.close()
def insert():
    user= input('Enter Username:')
    passw= input('Enter Password:')
    d1= {user:passw}
    f= open('manoram.txt','rb+')
    d= pickle.load(f)
    file=open('manoram.txt','rb+')
    d.update(d1)
    file.seek(0)
    pickle.dump(d,file)
    file.close()
    f.close()
def load():
    file= open('manoram.txt','rb')
    v= pickle.load(file)
    for i,j in v.items():
        print('Username:'+i)
        print('Password:'+j)
insert()
load()