from tkinter import *
import pickle
screen= Tk()
screen.geometry('200x220')
username=StringVar()
password=StringVar()
def log():
    user=username.get()
    pas=password.get()
    d={'u':user,'p':pas}
    file=open('save.txt','rb')
    c=pickle.load(file)
    if d==c:
        print("true")
    else:
        print('user not found')
l1=Label(screen, text='Welcome', bg='grey', height=1, width=420, font=('samanata', 20, 'bold')).pack()
l2=Label(screen,text='username*').pack()
e1=Entry(textvariable=username).pack()
l3=Label(screen,text='password*').pack()
e2=Entry(textvariable=password).pack()
b1= Button(text='Login',font='calabri',command=log).pack()
screen.mainloop()
