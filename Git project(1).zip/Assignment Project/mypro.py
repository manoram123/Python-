import pickle
d={}
my_file=open('myfile.txt','ab')
pickle.dump(d,my_file)
my_file.close()
def save():
    user = input('Enter Username:')
    passw = input('Enter Password:')
    d1 = {user: passw}
    file= open('myfile.txt','rb+')
    d= pickle.load(file)
    file.close()
    f=open('myfile.txt','rb+')
    d.update(d1)
    f.seek(0)
    pickle.dump(d,f)
    f.close()
def load():
    file= open('myfile.txt','rb')
    v= pickle.load(file)
    for i,j in v.items():
        print('Username:'+i)
        print('Password:'+j)
save()
load()