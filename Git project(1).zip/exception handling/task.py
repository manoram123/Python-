
try:
    x= int(input('enter a number:'))
    y= int(int(input('enter a number:')))
    print(x/y)
except ZeroDivisionError and ValueError as e:
    type(e)
    print('Error Detail:',e)




