class abc:
    def xyz(self,x):
        print(self)
        print(x)
    @classmethod
    def c_xyz(cls,x):
        print(cls)
        print(x)
    @staticmethod
    def s_xyz(x):
        print(x)
obj=abc()
obj.xyz(5)
obj.c_xyz(5)
obj.s_xyz(5)
