f= open('new.py','w')
f.close()
class abc:
    def xyz(self,x):
        print(self)
        print(x)

    def class_xyz(cls,x):
        print(cls)
        print(x)
    def static_xyz(x):
        print(x)
obj=abc()
obj.xyz(5)
obj.class_xyz(5)
obj.static_xyz(5)
