a= int(input("Enter Marks in Mathematics:"))
b= int(input("Enter Marks in English:"))
c= int(input("Enter Marks in Science:"))
d= int(input("Enter Marks in Nepali:"))
t= a+b+c+d
print("Total Marks:",t)
p= (t/400)*100
print("Percentage:",p)
if a<40 or b<40 or c<40:
    print("Fail")
else:
    if p>=70:
        print("Distinction")
    elif p>60 and  p<70:
        print("First Division")
    elif p>40 and p<60:
        print("Pass")


