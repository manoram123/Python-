a= int(input("Enter First Number:"))
b= int(input("Enter Second Number:"))
c= int(input("Enter Third Number:"))
if a<b and a<c:
    print(a, "is The Lowest Number!")
elif b<a and b<c:
    print(b, "is The Lowest Number!")
else:
    print(c, "is The Lowest Number!")


