a= input("Enter a number:")
print("Last Digit:",a[-1])
