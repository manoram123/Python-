x= (input("Enter Username:"))
p= int(input("Enter Password:"))
if x=="Manoram" and p==1234:
    print("U are logged in!")
else:
    print("Hacker alert!!!")
